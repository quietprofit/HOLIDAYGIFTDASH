# Holiday Gift Dashboard

## Quick Start
1. Install dependencies:
   npm install

2. Configure environment variables:
   Copy `.env.example` to `.env` and add your keys:
   - `GEMINI_API_KEY` (for Gift Idea Generator & Price Comparison)
   - `VITE_GOOGLE_MAPS_API_KEY` (for Interactive Shopping Route Map)
   - `CUSTOMER_ACCESS_CODE` (optional, defaults to HOLIDAY2026)

3. Start development server:
   npm run dev

4. Build for production:
   npm run build
   npm start
